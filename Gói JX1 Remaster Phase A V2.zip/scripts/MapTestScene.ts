import {
    _decorator,
    Component,
    Graphics,
    Node,
    Color,
    input,
    Input,
    EventKeyboard,
    KeyCode,
    JsonAsset,
    resources
} from 'cc';

import { IsometricGrid } from './IsometricGrid';
import { MapDefinition } from './MapDataTypes';
import { MapDataLoader } from './MapDataLoader';
import { MapTransition } from './MapTransition';
import { MapCameraBounds } from './MapCameraBounds';

const { ccclass, property } = _decorator;

@ccclass('MapTestScene')
export class MapTestScene extends Component {

    @property(Node)
    cameraNode: Node | null = null;

    @property
    viewWidth = 800;

    @property
    viewHeight = 450;

    private mapData: MapDefinition | null = null;
    private gridX = 9;
    private gridY = 12;
    private playerNode: Node | null = null;
    private transitioning = false;

    start() {
        this.loadInitialMap();

        input.on(
            Input.EventType.KEY_DOWN,
            this.onKeyDown,
            this
        );
    }

    onDestroy() {
        input.off(
            Input.EventType.KEY_DOWN,
            this.onKeyDown,
            this
        );
    }

    private loadInitialMap() {
        resources.load(
            'maps/map_001_village_test',
            JsonAsset,
            (err, asset) => {
                if (err || !asset) {
                    console.error('Khong nap duoc map 001', err);
                    return;
                }

                const data = asset.json as MapDefinition;
                const errors = MapDataLoader.validate(data);

                if (errors.length > 0) {
                    console.error('JSON ban do loi:', errors);
                    return;
                }

                this.mapData = data;

                const spawn = data.spawn_points.find(
                    item => item.type === 'player'
                );

                if (!spawn) {
                    console.error('Thieu diem spawn');
                    return;
                }

                this.gridX = spawn.x;
                this.gridY = spawn.y;

                this.drawGround();
                this.drawObstacles();
                this.createPlayer();
                this.followCamera();

                console.log('Da vao map:', data.map_id);
            }
        );
    }

    private onKeyDown(event: EventKeyboard) {
        if (this.transitioning) return;

        let dx = 0;
        let dy = 0;

        switch (event.keyCode) {
            case KeyCode.KEY_W:
            case KeyCode.ARROW_UP:
                dy = -1;
                break;

            case KeyCode.KEY_S:
            case KeyCode.ARROW_DOWN:
                dy = 1;
                break;

            case KeyCode.KEY_A:
            case KeyCode.ARROW_LEFT:
                dx = -1;
                break;

            case KeyCode.KEY_D:
            case KeyCode.ARROW_RIGHT:
                dx = 1;
                break;

            default:
                return;
        }

        this.movePlayer(dx, dy);
    }

    private movePlayer(dx: number, dy: number) {
        if (!this.mapData) return;

        const nextX = this.gridX + dx;
        const nextY = this.gridY + dy;

        if (!MapDataLoader.isWalkable(
            this.mapData,
            nextX,
            nextY
        )) {
            console.log('O bi chan:', nextX, nextY);
            return;
        }

        this.gridX = nextX;
        this.gridY = nextY;

        this.updatePlayerPosition();
        this.followCamera();
        this.checkPortal();
    }

    private checkPortal() {
        if (!this.mapData || this.transitioning) return;

        const portal = this.mapData.portals.find(
            item => item.x === this.gridX &&
                    item.y === this.gridY
        );

        if (!portal) return;

        this.transitioning = true;

        console.log('Dang chuyen ban do:', portal.id);

        MapTransition.loadTarget(
            this.mapData,
            portal.id,
            (error, result) => {
                if (error || !result) {
                    console.error('Chuyen ban do that bai:', error);
                    this.transitioning = false;
                    return;
                }

                this.mapData = result.mapData;
                this.gridX = result.spawnX;
                this.gridY = result.spawnY;

                this.removeLayer('GroundTiles');
                this.removeLayer('ObstacleTiles');

                this.drawGround();
                this.drawObstacles();

                this.updatePlayerPosition();
                this.followCamera();

                console.log(
                    'Da chuyen den map:',
                    result.mapData.map_id,
                    'tai:',
                    this.gridX,
                    this.gridY
                );

                this.transitioning = false;
            }
        );
    }

    private removeLayer(name: string) {
        const layer = this.node.getChildByName(name);

        if (layer) {
            layer.removeFromParent();
            layer.destroy();
        }
    }

    private createLayer(name: string): Graphics {
        const node = new Node(name);
        node.setParent(this.node);
        return node.addComponent(Graphics);
    }

    private drawDiamond(
        g: Graphics,
        x: number,
        y: number,
        color: Color
    ) {
        const p = IsometricGrid.gridToLocal(x, y);

        g.fillColor = color;
        g.moveTo(p.x, p.y + 16);
        g.lineTo(p.x + 32, p.y);
        g.lineTo(p.x, p.y - 16);
        g.lineTo(p.x - 32, p.y);
        g.close();
        g.fill();
    }

    private drawGround() {
        if (!this.mapData) return;

        const g = this.createLayer('GroundTiles');

        for (let y = 0; y < this.mapData.height; y++) {
            for (let x = 0; x < this.mapData.width; x++) {
                const color = (x + y) % 2 === 0
                    ? new Color(85, 135, 70, 255)
                    : new Color(98, 145, 78, 255);

                this.drawDiamond(g, x, y, color);
            }
        }
    }

    private drawObstacles() {
        if (!this.mapData) return;

        const g = this.createLayer('ObstacleTiles');

        for (const cell of this.mapData.blocked_cells) {
            this.drawDiamond(
                g,
                cell[0],
                cell[1],
                new Color(145, 65, 45, 255)
            );
        }
    }

    private createPlayer() {
        this.playerNode = new Node('PlayerStartMarker');
        this.playerNode.setParent(this.node);

        const g = this.playerNode.addComponent(Graphics);

        g.fillColor = new Color(245, 220, 100, 255);
        g.circle(0, 0, 10);
        g.fill();

        this.updatePlayerPosition();
    }

    private updatePlayerPosition() {
        if (!this.playerNode) return;

        const p = IsometricGrid.gridToLocal(
            this.gridX,
            this.gridY
        );

        this.playerNode.setPosition(p.x, p.y, 0);
    }

    private followCamera() {
        if (
            !this.cameraNode ||
            !this.playerNode ||
            !this.mapData
        ) return;

        MapCameraBounds.clamp(
            this.cameraNode,
            this.playerNode,
            this.mapData.width,
            this.mapData.height,
            this.viewWidth,
            this.viewHeight
        );
    }
}
