# JX1 Remaster - Phase A

## Da chuan bi
- Du lieu map 20x20.
- Toa do Isometric 64x32.
- Kieu du lieu map TypeScript.
- Ma ve nen ban do bang Cocos Graphics.
- 8 o vat can mau.
- Marker vi tri xuat hien nguoi choi.

## Chua kiem thu trong Cocos
- Scene MapTest.
- Hien thi ban do thuc te.
- Va cham khi di chuyen.
- Camera bam theo nhan vat.
- Dieu khien cam ung Android.

Khong danh dau Phase A hoan thanh truoc khi chay thu trong Cocos Creator.

## Cap nhat 25/11/2026 - Ban xem thu Preview
- Ban xem thu HTML5 tai preview/ da hoan thien: ve isometric tu JSON that, keo ban do, zoom 0.5-2, chuyen ban do qua cong 2 chieu, nen bai co rieng cho map_002, nhan nhan vat tu lat phia khi sat mep, camera clamp (clampCamera) khong cho keo vuot bien ban do.
- Kiem thu tu dong: test_phase_a PASS, test_portal_routes PASS, kiem tra camera Preview 6/6 PASS, kiem tra logic muc 2 (JS/camera/zoom/xoay) 8/8 PASS.
- KIEM THU CAM UNG TREN OPPO (Buoc 44, 25/11/2026): 10/10 muc PASS do nguoi dung truc tiep thao tac.
- Van chua chay thu trong Cocos Creator (can moi truong Editor Windows/macOS) - chua danh dau Phase A hoan thanh o muc engine.
