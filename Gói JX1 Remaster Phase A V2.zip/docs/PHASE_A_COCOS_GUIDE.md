# JX1 Remaster - Phase A

## 1. Phạm vi
- Ban do Isometric 20x20.
- Tile 64x32.
- Hai ban do thu nghiem.
- Du lieu JSON.
- Vat can va kiem tra di chuyen.
- Camera bounds.
- Module chuyen ban do.

## 2. Mo bang Cocos Creator 3.x

1. Cai Cocos Creator 3.x tren may Windows/macOS tuong thich.
2. Tao mot project 2D moi.
3. Mo thu muc project trong Cocos Creator.
4. Sao che thu muc scripts vao assets/scripts.
5. Sao che thu muc resources vao assets/resources.
6. Tao scene MapTest.
7. Tao node MapRoot.
8. Gan component MapTestScene vao MapRoot.
9. Tao Camera va gan vao truong cameraNode.
10. Kiem tra Console va chay scene.

## 3. Dieu khien thu nghiem
- W/A/S/D hoac mui ten: di chuyen.
- Thu di vao vat can.
- Thu di den cong dich chuyen.
- Kiem tra chuyen qua lai giua hai ban do.
- Kiem tra camera tai cac mep ban do.

## 4. Luu y
Day la goi ma nguon Phase A, khong phai project Cocos da
duoc mo va kiem thu thanh cong.

Can kiem tra lai API va bien dich TypeScript trong
phien ban Cocos Creator thuc te.

Chua co APK/AAB.
Chua co nhan vat B.
Khong su dung dich vu tra phi.
