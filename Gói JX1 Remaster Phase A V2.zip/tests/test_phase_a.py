import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAP_DIR = ROOT / "data/maps"
RESOURCE_DIR = ROOT / "assets/resources/maps"

maps = {}

for path in sorted(MAP_DIR.glob("map_*.json")):
    data = json.loads(path.read_text(encoding="utf-8"))

    assert data["projection"] == "isometric"
    assert data["tile_width"] == 64
    assert data["tile_height"] == 32
    assert data["width"] == 20
    assert data["height"] == 20

    for x, y in data["blocked_cells"]:
        assert 0 <= x < data["width"]
        assert 0 <= y < data["height"]

    for spawn in data["spawn_points"]:
        x, y = spawn["x"], spawn["y"]
        assert 0 <= x < data["width"]
        assert 0 <= y < data["height"]
        assert [x, y] not in data["blocked_cells"]

    resource = RESOURCE_DIR / path.name
    assert resource.exists()
    assert resource.read_bytes() == path.read_bytes()

    maps[data["map_id"]] = data
    print("PASS DATA:", data["map_id"])

for map_id, data in maps.items():
    for portal in data["portals"]:
        target_id = portal["target_map_id"]
        assert target_id in maps

        target = maps[target_id]
        x, y = portal["target_x"], portal["target_y"]

        assert 0 <= x < target["width"]
        assert 0 <= y < target["height"]
        assert [x, y] not in target["blocked_cells"]

        print("PASS PORTAL:", map_id, "->", target_id)

# Kiem tra gioi han camera cho map 20x20.
map_width = 20
map_height = 20
view_width = 800
view_height = 450

min_x = -map_height * 32
max_x = map_width * 32
min_y = -(map_width + map_height - 1) * 16
max_y = 16

assert max_x - min_x >= view_width
assert max_y - min_y >= view_height

min_camera_x = min_x + view_width / 2
max_camera_x = max_x - view_width / 2
min_camera_y = min_y + view_height / 2
max_camera_y = max_y - view_height / 2

for x, y in [(0, 0), (19, 19), (9, 12)]:
    px = (x - y) * 32
    py = -(x + y) * 16

    cx = max(min_camera_x, min(max_camera_x, px))
    cy = max(min_camera_y, min(max_camera_y, py))

    assert min_camera_x <= cx <= max_camera_x
    assert min_camera_y <= cy <= max_camera_y

print("PASS CAMERA BOUNDS")
print("ALL PHASE A STATIC TESTS PASSED")
