import json
from pathlib import Path

folder = Path("data/maps")
maps = {
    json.loads(p.read_text(encoding="utf-8"))["map_id"]:
    json.loads(p.read_text(encoding="utf-8"))
    for p in folder.glob("map_*.json")
}

def walkable(m, x, y):
    return (
        0 <= x < m["width"]
        and 0 <= y < m["height"]
        and [x, y] not in m["blocked_cells"]
    )

def reachable(m, start, goal):
    from collections import deque

    queue = deque([start])
    visited = {start}

    while queue:
        x, y = queue.popleft()

        if (x, y) == goal:
            return True

        for dx, dy in [(1,0),(-1,0),(0,1),(0,-1)]:
            nxt = (x + dx, y + dy)

            if nxt not in visited and walkable(m, *nxt):
                visited.add(nxt)
                queue.append(nxt)

    return False

for map_id, m in maps.items():
    spawn = next(
        s for s in m["spawn_points"]
        if s["type"] == "player"
    )

    start = (spawn["x"], spawn["y"])

    for portal in m["portals"]:
        goal = (portal["x"], portal["y"])

        assert reachable(m, start, goal), (
            f"Khong co duong di: {map_id} -> {goal}"
        )

        target = maps[portal["target_map_id"]]
        destination = (portal["target_x"], portal["target_y"])

        assert walkable(target, *destination)

        print(
            "PASS ROUTE:",
            map_id,
            start,
            "->",
            goal,
            "->",
            portal["target_map_id"],
            destination
        )

print("ALL PORTAL ROUTE TESTS PASSED")
