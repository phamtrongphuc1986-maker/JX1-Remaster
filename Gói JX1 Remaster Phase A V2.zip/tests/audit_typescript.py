import re
from pathlib import Path

root = Path(".")
script_dir = root / "scripts"
errors = []

for source in sorted(script_dir.glob("*.ts")):
    text = source.read_text(encoding="utf-8")

    imports = re.findall(
        r"""from\s+['"](\.[^'"]+)['"]""",
        text
    )

    for item in imports:
        target = source.parent / item
        candidates = [
            target.with_suffix(".ts"),
            target / "index.ts"
        ]

        if not any(p.exists() for p in candidates):
            errors.append(f"{source}: thieu import {item}")

    if "\x00" in text:
        errors.append(f"{source}: co ky tu NULL")

    print("CHECK:", source)

if errors:
    print("\nLOI:")
    for error in errors:
        print("-", error)
    raise SystemExit(1)

print("\nALL LOCAL TYPESCRIPT IMPORTS PASSED")
print("Luu y: chua bien dich TypeScript voi Cocos Creator.")
