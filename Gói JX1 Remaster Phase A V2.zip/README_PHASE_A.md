# JX1 Remaster - Phase A

Goi ma nguon he thong ban do Isometric.

## Thanh phan
- scripts/: TypeScript
- data/maps/: JSON goc
- assets/resources/maps/: JSON cho Cocos resources
- tests/: kiem thu tu dong
- docs/: tai lieu

## Kiem thu tren Ubuntu
python3 tests/test_phase_a.py
python3 tests/test_portal_routes.py
python3 tests/audit_typescript.py

## Trang thai
Kiem thu tinh da PASS theo ket qua tren VPS.
Chua xac nhan chay trong Cocos Creator.
Chua build APK/AAB.
